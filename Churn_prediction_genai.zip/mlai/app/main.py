from fastapi import FastAPI
from app.routes import upload, clean, train, predict

app = FastAPI(
    title="Customer Churn Prediction API",
    description="Predict customer churn using ML and explain with GenAI",
    version="o1"
)

app.include_router(upload.router, prefix="/upload", tags=["Upload"])
app.include_router(clean.router, prefix="/data_cleaning", tags=["Data Cleaning"])
app.include_router(train.router, prefix="/train_model", tags=["Model Training"])
app.include_router(predict.router, prefix="/predict", tags=["Prediction"])
