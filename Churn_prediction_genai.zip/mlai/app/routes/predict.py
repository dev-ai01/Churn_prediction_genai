from fastapi import APIRouter, UploadFile, File, Form
import pandas as pd
import joblib
import os, json
from app.storage.models.genai import explain_prediction
from app.routes.clean import clean_dataset_train # Import the reusable function

router = APIRouter()
DATA_DIR = "app/storage/cleaned_data"
CLEANED_FILE_PATH = os.path.join(DATA_DIR, "cleaned_data.csv")
CLEANING_CONFIG_PATH = os.path.join(DATA_DIR, "cleaning_config.json")

@router.post("/predict")
async def predict_churn(file: UploadFile = File(...), model_name: str = Form(...)):
    # Step 1: Load model
    model_path = os.path.join("app/storage/models", model_name)
    if not os.path.exists(model_path):
        return {"error": f"Model '{model_name}' not found."}
    
    model = joblib.load(model_path)

    df = pd.read_csv(file.file)

    try:
        with open(CLEANING_CONFIG_PATH, "r") as f:
            cleaning_config = json.load(f)
    except FileNotFoundError:
        return {"error": "No cleaning configuration found. Please run /clean_data first."}
    # Clean the raw data using shared logic
    df_cleaned = clean_dataset_train(
        missing_value_strategy=cleaning_config["missing_value_strategy"],
        encoding_strategy=cleaning_config["encoding_strategy"],
        scaling_strategy=cleaning_config["scaling_strategy"],
        target_column=cleaning_config["target_column"]
    )
    
    target_column=cleaning_config["target_column"]

    if target_column in df_cleaned.columns:
        df_cleaned = df_cleaned.drop(columns=target_column)

    # Step 3: Predict
    predictions = model.predict(df_cleaned)

    # Step 4: Generate summaries
    results = []
    for i, row in df.iterrows():  # iterate on original (unencoded) data
        input_row = row.to_dict()
        pred = int(predictions[i])
        summary = explain_prediction(input_row, str(pred))
        results.append({
            **input_row,
            "prediction": pred,
            "summary": summary
        })

    return {"results": results}