from fastapi import APIRouter, UploadFile, File, Form
import pandas as pd
from typing import List
import os
from io import BytesIO

router = APIRouter()

DATA_DIR = "app/storage/cleaned_data"
os.makedirs(DATA_DIR, exist_ok=True)

@router.post("/")
async def upload_dataset(file: UploadFile = File(...), target_column: str = Form(...)):
    try:
        contents = await file.read()
        if file.filename.endswith(".csv"):
            df = pd.read_csv(BytesIO(contents))
        elif file.filename.endswith((".xls", ".xlsx")):
            df = pd.read_excel(BytesIO(contents))
        else:
            return {"error": "Unsupported file type. Please upload a .csv or .xlsx file."}
    except Exception as e:
        return {"error": f"File read failed: {str(e)}"}

    # Saving raw version for future use
    raw_path = os.path.join(DATA_DIR, "raw_uploaded.csv")
    df.to_csv(raw_path, index=False)

    # Metadata
    column_types = df.dtypes.apply(str).to_dict()
    missing_values = df.isnull().sum().to_dict()
    sample_preview = df.head().to_dict(orient="records")

    if target_column not in df.columns:
        return {"error": f"Target column '{target_column}' not found in uploaded file."}

    return {
        "message": "Dataset uploaded successfully",
        "columns": list(df.columns),
        "target_column": target_column,
        "column_types": column_types,
        "missing_values": missing_values,
        "sample_preview": sample_preview
    }