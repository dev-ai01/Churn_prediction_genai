from fastapi import APIRouter, Form
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, MinMaxScaler, OneHotEncoder, LabelEncoder
import os, joblib, json
from sklearn.preprocessing import LabelEncoder, StandardScaler 

router = APIRouter()

DATA_DIR = "app/storage/cleaned_data"
RAW_FILE_PATH = os.path.join(DATA_DIR, "raw_uploaded.csv")
CLEANED_FILE_PATH = os.path.join(DATA_DIR, "cleaned_data.csv")
CLEANING_CONFIG_PATH = os.path.join(DATA_DIR, "cleaning_config.json")

@router.post("/")
def clean_dataset(missing_value_strategy: str = "drop",
    encoding_strategy: str = "label",
    scaling_strategy: str = "standard",
    target_column: str = None
):
    
    cleaning_config = {
        "missing_value_strategy": missing_value_strategy,
        "encoding_strategy": encoding_strategy,
        "scaling_strategy": scaling_strategy,
        "target_column": target_column
    }

    with open(CLEANING_CONFIG_PATH, "w") as f:
        json.dump(cleaning_config, f)

    try:
        df = pd.read_csv(RAW_FILE_PATH)
    except FileNotFoundError:
        return {"error": "No uploaded dataset found. Please upload data first."}

    if target_column not in df.columns:
        raise ValueError(f"Target column '{target_column}' not found in data.")

    target = df[target_column]
    features = df.drop(columns=[target_column])

    # Handling missing values
    if missing_value_strategy == "drop":
        features = features.dropna()
    elif missing_value_strategy in ["mean", "median", "most_frequent"]:
        imputer = SimpleImputer(strategy=missing_value_strategy)
        features = pd.DataFrame(imputer.fit_transform(features), columns=features.columns)
    else:
        raise ValueError("Invalid missing_value_strategy")

    # Encoding categorical features
    categorical_cols = features.select_dtypes(include=["object", "category"]).columns

    if encoding_strategy == "label":
        for col in categorical_cols:
            encoder = LabelEncoder()
            features[col] = encoder.fit_transform(features[col].astype(str))
    elif encoding_strategy == "onehot":
        features = pd.get_dummies(features, drop_first=True)
    else:
        raise ValueError("Invalid encoding_strategy")

    # Scaling numeric features
    numeric_cols = features.select_dtypes(include=["int64", "float64"]).columns
    if scaling_strategy == "standard":
        scaler = StandardScaler()
    elif scaling_strategy == "minmax":
        scaler = MinMaxScaler()
    else:
        raise ValueError("Invalid scaling_strategy")

    features[numeric_cols] = scaler.fit_transform(features[numeric_cols])

    df_cleaned = features.copy()
    df_cleaned[target_column] = target.reset_index(drop=True)
    
    os.makedirs(DATA_DIR, exist_ok=True)
    df_cleaned.to_csv(CLEANED_FILE_PATH, index=False)

    return df_cleaned.head(5).to_dict(orient="records")


def clean_dataset_train(missing_value_strategy: str = "drop",
    encoding_strategy: str = "label",
    scaling_strategy: str = "standard",
    target_column: str = None
):
    
    cleaning_config = {
        "missing_value_strategy": missing_value_strategy,
        "encoding_strategy": encoding_strategy,
        "scaling_strategy": scaling_strategy,
        "target_column": target_column
    }

    with open(CLEANING_CONFIG_PATH, "w") as f:
        json.dump(cleaning_config, f)

    try:
        df = pd.read_csv(RAW_FILE_PATH)
    except FileNotFoundError:
        return {"error": "No uploaded dataset found. Please upload data first."}

    if target_column not in df.columns:
        raise ValueError(f"Target column '{target_column}' not found in data.")

    target = df[target_column]
    features = df.drop(columns=[target_column])

    # Handling missing values
    if missing_value_strategy == "drop":
        features = features.dropna()
    elif missing_value_strategy in ["mean", "median", "most_frequent"]:
        imputer = SimpleImputer(strategy=missing_value_strategy)
        features = pd.DataFrame(imputer.fit_transform(features), columns=features.columns)
    else:
        raise ValueError("Invalid missing_value_strategy")

    # Encoding categorical features
    categorical_cols = features.select_dtypes(include=["object", "category"]).columns

    if encoding_strategy == "label":
        for col in categorical_cols:
            encoder = LabelEncoder()
            features[col] = encoder.fit_transform(features[col].astype(str))
    elif encoding_strategy == "onehot":
        features = pd.get_dummies(features, drop_first=True)
    else:
        raise ValueError("Invalid encoding_strategy")

    # Scaling numeric features
    numeric_cols = features.select_dtypes(include=["int64", "float64"]).columns
    if scaling_strategy == "standard":
        scaler = StandardScaler()
    elif scaling_strategy == "minmax":
        scaler = MinMaxScaler()
    else:
        raise ValueError("Invalid scaling_strategy")

    features[numeric_cols] = scaler.fit_transform(features[numeric_cols])

    df_cleaned = features.copy()
    df_cleaned[target_column] = target.reset_index(drop=True)
    
    # os.makedirs(DATA_DIR, exist_ok=True)
    # df_cleaned.to_csv(CLEANED_FILE_PATH, index=False)

    return df_cleaned
