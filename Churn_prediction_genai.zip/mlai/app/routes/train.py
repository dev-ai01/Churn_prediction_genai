from fastapi import APIRouter, Form
import pandas as pd
import os, joblib
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from app.routes.clean import clean_dataset_train
import json

router = APIRouter()

DATA_DIR = "app/storage/cleaned_data"
CLEANING_CONFIG_PATH = os.path.join(DATA_DIR, "cleaning_config.json")
DATA_DIR = "app/storage/cleaned_data"
RAW_FILE_PATH = os.path.join(DATA_DIR, "raw_uploaded.csv")
MODEL_DIR = "app/storage/models"
os.makedirs(MODEL_DIR, exist_ok=True)


@router.post("/train_model")
def train_model(
    models: str = Form("logistic,randomforest,xgboost"),
):
    try:
        raw_df = pd.read_csv(RAW_FILE_PATH)
    except FileNotFoundError:
        return {"error": "Raw data not found. Please upload the dataset first."}

    try:
        with open(CLEANING_CONFIG_PATH, "r") as f:
            cleaning_config = json.load(f)
    except FileNotFoundError:
        return {"error": "No cleaning configuration found. Please run /clean_data first."}
    # Cleaning the raw data using shared logic
    cleaned_df = clean_dataset_train(
        missing_value_strategy=cleaning_config["missing_value_strategy"],
        encoding_strategy=cleaning_config["encoding_strategy"],
        scaling_strategy=cleaning_config["scaling_strategy"],
        target_column=cleaning_config["target_column"]
    )
    
    target_column=cleaning_config["target_column"]
    if target_column not in raw_df.columns:
        return {"error": f"Target column '{target_column}' not found in dataset."}
    # Saving cleaned data for reference
    cleaned_df.to_csv(os.path.join(DATA_DIR, "cleaned_data_train.csv"), index=False)

    X = cleaned_df.drop(columns=[target_column])
    y = cleaned_df[target_column]

    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Parse models to train
    selected_models = [m.strip().lower() for m in models.split(",")]
    results = {}

    for model_name in selected_models:
        if model_name == "logistic":
            model = LogisticRegression(max_iter=1000)
        elif model_name == "randomforest":
            model = RandomForestClassifier()
        elif model_name == "xgboost":
            model = XGBClassifier(use_label_encoder=False, eval_metric='logloss')
        else:
            continue  

        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        model_path = os.path.join(MODEL_DIR, f"{model_name}_model.pkl")
        joblib.dump(model, model_path)

        results[model_name] = {
            "accuracy": round(accuracy_score(y_test, y_pred), 4),
            "precision": round(precision_score(y_test, y_pred, average='weighted', zero_division=0), 4),
            "recall": round(recall_score(y_test, y_pred, average='weighted', zero_division=0), 4),
            "f1_score": round(f1_score(y_test, y_pred, average='weighted', zero_division=0), 4),
            "confusion_matrix": confusion_matrix(y_test, y_pred).tolist(),
            "model_path": model_path
        }

    return {
        "message": "Models trained and saved successfully",
        "results": results
    }
