import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

def explain_prediction(row: dict, prediction: str) -> str:
    prompt = f"""
    A customer has the following profile:
    {row}

    The churn prediction is: {prediction}

    In 1-2 lines, explain in simple English why this customer is likely or unlikely to churn.
    """
    client = OpenAI()
    try:
        response = client.responses.create(
            model="gpt-4o-mini",
            input= prompt,
            temperature=0            
        )
        return response.output[0].content[0].text
    except Exception as e:
        return f"GenAI explanation failed: {str(e)}"
